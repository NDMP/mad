package com.example.myapp4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private String currentInput = "";
    private String operator = "";
    private double firstOperand = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        int[] numberButtonIds = {
                R.id.button_0, R.id.button_1, R.id.button_2, R.id.button_3,
                R.id.button_4, R.id.button_5, R.id.button_6,
                R.id.button_7, R.id.button_8, R.id.button_9
        };

        for (int i = 0; i <= 9; i++) {
            int finalI = i;
            findViewById(numberButtonIds[i]).setOnClickListener(v -> appendToInput(String.valueOf(finalI)));
        }

        findViewById(R.id.button_add).setOnClickListener(v -> setOperator("+"));
        findViewById(R.id.button_subtract).setOnClickListener(v -> setOperator("-"));
        findViewById(R.id.button_multiply).setOnClickListener(v -> setOperator("*"));
        findViewById(R.id.button_divide).setOnClickListener(v -> setOperator("/"));
        findViewById(R.id.button_equal).setOnClickListener(v -> calculateResult());
        findViewById(R.id.button_clear).setOnClickListener(v -> clearInput());
    }

    private void appendToInput(String input) {
        currentInput += input;
        display.setText(currentInput);
    }

    private void setOperator(String op) {
        if (!currentInput.isEmpty()) {
            firstOperand = Double.parseDouble(currentInput);
            operator = op;
            currentInput = "";
        }
    }

    private void calculateResult() {
        if (!currentInput.isEmpty() && !operator.isEmpty()) {
            double secondOperand = Double.parseDouble(currentInput);
            double result = 0;

            switch (operator) {
                case "+": result = firstOperand + secondOperand; break;
                case "-": result = firstOperand - secondOperand; break;
                case "*": result = firstOperand * secondOperand; break;
                case "/":
                    if (secondOperand == 0) {
                        display.setText("Error");
                        return;
                    } else {
                        result = firstOperand / secondOperand;
                    }
                    break;
            }

            currentInput = String.valueOf(result);
            display.setText(currentInput);
        }
    }

    private void clearInput() {
        currentInput = "";
        operator = "";
        display.setText("");}
}